import java.net.*;
import java.io.*; 
class server 
{
   
    ServerSocket server;
    Socket socket;

    BufferedReader br;
    PrintWriter out;

   //constructor 
    public server()
  {
       try{
           server=new ServerSocket(7778);
           System.out.println("The server is ready to accept connection");
           System.out.println("waiting...");
           socket = server.accept();
           br=new BufferedReader(new InputStreamReader(socket.getInputStream()));
           out=new PrintWriter(socket.getOutputStream());
           startReading();
           startWriting();

        } catch(Exception e) {
            e.printStackTrace();
        }
  
    }

   
public void startReading()
{
   //thread-read 

   Runnable r1=() -> {
       
      System.out.println("reader started..");

    try{

      
         while(true)
         {
              String msg=br.readLine();
              if(msg.equals("exit"))
              {
                 System.out.println("Client terminated the chat");
                 break;
              }
              System.out.println("Clent : "+msg);  
           
         }
      }
      catch(Exception e)
      {
            //e.printStackTrace();
            System.out.println("Connection closed");
      }

   };

   new Thread(r1).start();
 
}

public void startWriting()
{
   //thread - data from user and sent to clent
   Runnable r2=()->{
      System.out.println("writer started..");
      
      try{
     
        while(!socket.isClosed())
         {
        
            BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in)); 
            String content=br1.readLine();

            out.println(content);
            out.flush();
            
            if(content.equals("exit"))
            {
                socket.close();
                break;
            }

        
        }
      } catch (Exception e)  {
       // e.printStackTrace();
       System.out.println("Connection closed");

      }
     
};

   new Thread(r2).start();
}


  public static void main(String[] args) {
      System.out.println("this is server...going to start server");
      new server();
}
public ServerSocket getServer() {
   return server;
}
public void setServer(ServerSocket server) {
   this.server = server;
}
public Socket getSocket() {
   return socket;
}
public void setSocket(Socket socket) {
   this.socket = socket;
}
public BufferedReader getBr() {
   return br;
}
public void setBr(BufferedReader br) {
   this.br = br;
}
public PrintWriter getOut() {
   return out;
}
public void setOut(PrintWriter out) {
   this.out = out;
}
}
